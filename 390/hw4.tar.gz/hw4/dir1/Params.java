public class Params {
    public static void main(String[] args) {
        chant(3);
    }
    
    public static void chant(int times) {
        for (int i = 1; i <= times; i++) {
            System.out.println("Hurrah!");
        }
    }
}
