
public class Special {
    public static void main(String[] args) {
        System.out.println();
	System.out.println("This is a very special message.");
	System.out.println("Do you agree?");
    }
}
