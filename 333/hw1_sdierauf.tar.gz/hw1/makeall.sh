cp ../../libgtest.a . && make clean && make all
